﻿define MK = Character('Mr Mako', color="#86A1B3") #aiden
image MK = "images/MK/MK.png"
image MK givingbirth:
    "images/MK/MRMAKOgivingbirth.png"
image MK talking:
    "images/MK/MRMAKOhappy.png"
image MK sad:
    "images/MK/MRMAKOnuetral.png"


define M = Character('Mr Mako', color="#86A1B3")
image M = "images/M/M.png"

define JO = Character('Joseph', color="#3E3DA3FF") #joseph?
image JO = "images/JO/JO.png"

define CK = Character('Charlie', color="#8A1616") #joseph?
image CK = "images/CK/CK.png"

define JK = Character('Mr Jackonsky', color="#C3EC63") #nicole
image JK = "images/JK/JK.png"
image JK talking:
    "images/JK/MRJACKONSKYhappytalking.png"
image JK sad:
    "images/JK/MRJACKONSKYnuetral.png"
image JK sad_talking:
    "images/JK/MRJACKONSKYtalking.png"

define TV = Character('Television', color="#4F2E2D") #Yani

define NS = Character('Nurse', color="#264FAD")
image NS = "images/NS/NS.png"

define L = Character('Liam', color="#77C8E0")
image L = "images/L/L.png"
image L talking:
    "images/L/LIAMhappy(talking).png"
image L sad:
    "images/L/LIAMneutral.png"
image L sad_talking:
    "images/L/LIAMneutral(talking).png"

define P = Character('Piitrah', color="#A363EC")
image P = "images/P/P.png"
image P talking:
    "images/P/PIITRAHhappy(talking).png"
image P sad:
    "images/P/PIITRAHneutral.png"
image P superhappy:
    "images/P/PIITRAHsuperhappy.png"
image P sad_talking:
    "images/P/PIITRAHneutral.png"
image P pose2:
    "images/P/PIITRAH🫰happy(talking).png"
image P pose2_sad:
    "images/P/PIITRAH🫰smiling.png"
image P pose2_talking:
    "images/P/PIITRAH🫰superhappy(talking).png"



define I = Character('Isabelle', color="#FF6F6F")
image I = "images/I/I.png"
image I talking:
    "images/I/ISABELLEtalking.png"
image I sad:
    "images/I/ISABELLEneutral.png"
image I sad_talking:
    "images/I/ISABELLEneutral.png"
image I peacesign:
    "images/I/ISABELLEhappy(peace).png"

define E = Character('Eriq', color="#dbd6aa") #emna
image E:
    "images/E/E.png"
image E talk:
    "images/E/ERIQhappy.png"
image E hip:
    "image/E/ERIQsmile(hip)"
image E hip_talk:
    "images/E/ERIQHAPPY(hip).png"
image E sad:
    "images/E/ERIQneutral.png"
image E sad_hip:
    "images/E/ERIQneutral(hip).png"
image E sad_talk:
    "images/E/ERIQtalking.png"
image E sad_hip_talk:
    "images/E/ERIQtalking(hip).png"

define NA = Character(' ', color="#575757",)

define A = Character('Angel', color="#F0AEE7") #maira
image A:
    "images/A/A.png"
image A talking:
    "images/A/ANGELhappy.png"
image A sad:
    "images/A/ANGELneutral.png"
image A sad_talking:
    "images/A/ANGELneutral(talking).png"

define LL = Character('Lunch Lady', color="#82cabe") #aiden


default angelpoints = 0
default josephpoints = 0



transform center_left:
    xalign 0.4
    yalign 1.0

transform center_farleft:
    xalign 0.2
    yalign 1.0

transform center_right:
    xalign 0.6
    yalign 1.0

transform center_farright:
    xalign 0.8
    yalign 1.0


#usefull stuff
#play music "music.mp3"
#show char = show E happy
#hide char = hide E

#show e happy at left
#with move


image mixer = im.Scale("mixer.jpg", 1920, 1080)

label start:

    scene black
    scene warning
    with fade
    pause
    scene black

    voice "E/E1.mp3"
    E "Being closeted means carrying a truth you can’t always say out loud."
    voice "E/E2.mp3"
    E "It’s editing yourself, watching your words, and hiding parts of who you are just to feel safe."
    voice "E/E3.mp3"
    E "People may think they know you, but they only see what you’re allowed to show."
    voice "E/E4.mp3"
    E "Staying closeted isn’t weakness."
    voice "E/E5.mp3"
    E "It’s survival."
    voice "E/E6.mp3"
    E "There’s no deadline to come out and no rule that says you owe anyone your truth before you’re ready."
    voice "E/E7.mp3"
    E "You are valid even in silence, and when the time comes, your story will still be yours to tell."
    voice "E/E15.mp3"
    E "Am I ready?"


    scene bathroomscene
    with fade

    

    play sound "gunshot.mp3"

    NA "*Gunshot*"
    voice "JO/JO_1.mp3"
    JO "I couldn't do it anymore"
    voice "JO/JO_2.mp3"
    JO "Knowing what I do.."
    voice "JO/JO_3.mp3"
    JO "How could I live knowing what I did..?"
    voice "JO/JO_4.mp3"
    JO "I had to do it"
    voice "JO/JO_5.mp3"
    JO "Despite what they said"
    voice "JO/JO_6.mp3"
    JO "Who could stop them?"
    voice "JO/JO_7.mp3"
    JO "Why even try..?"
    voice "JO/JO_8.mp3"
    JO "I dont regret what I did"
    JO "..."
    voice "JO/JO_9.mp3"
    JO "Where do we go when we pass..?"
    voice "JO/JO_10.mp3"
    JO "Billie eilish might know"
    voice "JO/JO_11.mp3"
    JO "But I sure dont"
    voice "JO/JO_12.mp3"
    JO "Regardless.."
    voice "JO/JO_13.mp3"
    JO "Life will go on"
    voice "JO/JO_14.mp3"
    JO "The sun will rise and fall"
    voice "JO/JO_15.mp3"
    JO "Water will flow"
    voice "JO/JO_16.mp3"
    JO "Kids will use research time irresponsibly"
    voice "JO/JO_17.mp3"
    JO "And Eriq will still think he's straight."
    voice "JO/JO_18.mp3"
    JO "The show must go on..."

    jump realstart
    

label realstart:
    

    play music [
    "audio/wearecharliekirkHYPERPOP.mp3",
    "audio/wearecharliekirkFONK.mp3",
    "audio/wearecharliekirkOG.mp3",
    "audio/fivenightsatkirkys.mp3",
    "audio/wearecharliekirkJERSEYDRILLREMIX.mp3"
    ] fadein 1.5 fadeout 1.5 loop
    
    scene outside
    with fade

    show E at center
    with dissolve
    voice "E/E16.mp3"
    E "Another day another slayy perriouddd!!"
    voice "E/E17.mp3"
    E "(Sophomore has been very stressfull)"
    voice "E/E18.mp3"
    E "(With all of the classes and drama going on its hard to get any sleep)"
    voice "E/E19.mp3"
    E "(But one person keeps me going..)"
    voice "E/E20.mp3"
    E "(My friend Angel!)"
    

    show A at center_left
    show E at center_right
    with dissolve

    show A talking
    voice "A/A1.mp3"
    A "Hya there Eriq!"
    show A

    show A talking
    voice "A/A2.mp3"
    A "How did you sleep last night?"
    show A

    show E talk
    voice "E/E21.mp3"
    E "Not well, I stayed up last night till 2am doing homework for Mr. Morales."
    show E

    show A talking
    voice "A/A3.mp3"
    A "Well thats not good, you should really work on getting better sleep!"
    show A

    show A talking
    voice "A/A4.mp3"
    A "Why didn't you do it in research?"
    show A

    show E talk
    voice "E/E22.mp3"
    E "I was drawing as usual.."
    show E

    show A talking
    voice "A/A5.mp3"
    A "Classic Eriq..."
    show A

    show A talking
    voice "A/A6.mp3"
    A "You know.."
    show A

    show A talking
    voice "A/A7.mp3"
    A "For a straight guy, you draw a lot of shirtless men."
    show A

    show E
    E ".."

    show E sad_hip
    voice "E/E23.mp3"
    E "gyulp"
    show E

    show A talking
    voice "A/A8.mp3"
    A "Hahah, just yanking your chain"
    show A

    show A talking
    voice "A/A9.mp3"
    A "Lets get inside before we're late"
    show A

    show E talk
    voice "E/E24.mp3"
    E "Heh.. yeah you're right.."
    show E

    hide A
    hide E
    


    scene mixer
    with fade

    show E at center
    with dissolve

    voice "E/E25.mp3"
    E "The mixer.."
    voice "E/E26.mp3"
    E "For a small school like Neocity there are alot of people here in the morning."
    voice "E/E27.mp3"
    E "Everyone finds their group"
    voice "E/E28.mp3"
    E "Gets breakfast"
    voice "E/E29.mp3"
    E "And prepares for class"
    voice "E/E30.mp3"
    E "Where am I going to go...?"

    menu:

        "Where am I going to go...?"

        "Breakfast line":

            jump breakfast_D1

        "Walk around":

            jump friendgroup_D1
    

label breakfast_D1:
    E "*rumble.. rumble*"
    voice "E/E44.mp3"
    E "…Wow, my stomach is not being subtle today."
    voice "E/E45.mp3"
    E "I really forgot to eat breakfast this morning."
    voice "E/E46.mp3"
    E "That’s what I get for hitting snooze one too many times."
    voice "E/E47.mp3"
    E "Guess I’ll get some breakfast before I pass out in class."

    scene mixer2
    with fade

    show E at center
    with dissolve

    voice "E/E31.mp3"
    E "(Wow, the second mixer is pretty packed.)"
    voice "E/E32.mp3"
    E "(So much for it being early.)"
    voice "E/E33.mp3"
    E "(Guess a lot of people had the same idea this morning.)"
    voice "E/E34.mp3"
    E "(Everyone’s chatting and laughing like they’re wide awake.)"
    voice "E/E35.mp3"
    E "(I don’t understand how anyone has this much energy before seven.)"
    voice "E/E36.mp3"
    E "(It’s too fucking loud in here for six in the morning.)"
    voice "E/E37.mp3"
    E "(My head hurts a little, but food should help.)"
    voice "E/E38.mp3"
    E "(At least today’s breakfast is supposed to be good.)"
    voice "E/E39.mp3"
    E "(For a school full of twinks there sure are a lot of fatasses)"
    voice "E/E40.mp3"
    E "(I knew coming early wouldn’t mean avoiding the line.)"
    voice "E/E41.mp3"
    E "(It never does.)"
    voice "E/E42.mp3"
    E "(Still better than waiting even longer.)"
    voice "E/E43.mp3"
    E "(Might as well get in it now.)"

    scene lunchline
    with fade

    voice "E/E48.mp3"
    E "(God, I hope this line moves quickly.)"
    voice "E/E48half.mp3"
    E "(My stomach feels like it’s eating itself.)"
    voice "E/E49.mp3"
    E "(I don’t want to rush through eating.)"
    voice "E/E50.mp3"
    E "(But I also don’t want to be late for my first class.)"
    voice "E/E51.mp3"
    E "(Why is everything a trade-off this early in the day?)"

    voice "LL/LL1.mp3"
    LL "Don’t forget your fruit, honey."

    with dissolve

    voice "E/E52.mp3"
    E "Oh— yeah. Sorry."

    voice "E/E53.mp3"
    E "(I always forget that part.)"

    E "*grabs fruit*"

    voice "E/E54.mp3"
    E "(At least it looks fresh today.)"

    voice "LL/LL2.mp3"
    LL "Scan your ID now."

    E "*scans*"

    voice "E/E55.mp3"
    E "(I wonder how many times she’s seen my name pop up this semester.)"

    voice "LL/LL3.mp3"
    LL "Next in line, please."

    voice "E/E56.mp3"
    E "(I can’t tell sometimes if the lunch lady loves me or hates me.)"

    voice "E/E57.mp3"
    E "(Her tone never changes.)"

    voice "E/E58.mp3"
    E "(Whatever.)"

    voice "E/E59.mp3"
    E "(Now I just need to find a seat somewhere.)"

    voice "E/E60.mp3"
    E "(Preferably one that isn’t right next to the loudest table.)"


    scene mixer2
    with fade

    show MK at center_left
    with dissolve
    show JK at center_right 
    with dissolve

    show MK at center_left
    with dissolve

    show JK at center_right
    with dissolve

    show MK at center_left
    MK "*Eating breakfast*"

    show JK at center_right
    JK "*Eating breakfast*"

    show MK talking at center_left
    MK "So... Jackonsky, did anything interesting happen yesterday?"

    show MK at center_left

    show JK talking at center_right
    JK "Hmm... not really. It was mostly the same old stuff. What about you?"

    show JK at center_right

    show MK talking at center_left
    MK "Other than failing a few students? Not much."

    show MK at center_left

    show JK talking at center_right
    JK "How come your always failing your students?"

    show JK at center_right

    show MK talking at center_left
    MK "It's called being dedicated."

    show MK at center_left

    show JK talking at center_right
    JK "Pretty sure that's not what dedication means."

    show JK at center_right

    show MK talking at center_left
    MK "Agree to disagree."

    show MK at center_left

    show JK talking at center_right
    JK "..."

    show JK at center_right

    show MK at center_left
    MK "..."

    NA "*complete silence*"

    show JK talking at center_right
    JK "You know, we're really good at conversations."

    show JK at center_right

    show MK talking at center_left
    MK "*Laughs* Anyway, do you have any plans for this weekend?"

    show MK at center_left

    show MK talking at center_left
    MK "Actually, I was thinking about going to Gag City for lunch."

    show MK at center_left

    show JK talking at center_right
    JK "Really? I've heard good things about that place."

    show JK at center_right

    show MK talking at center_left
    MK "That's what everyone keeps telling me. I figured it was finally time to see if the food is worth all the hype."

    show MK at center_left

    show JK talking at center_right
    JK "And?"

    show JK at center_right

    show MK talking at center_left
    MK "I was wondering if you'd like to come with me."

    show MK at center_left

    show JK talking at center_right
    JK "I'd love that!"

    show JK at center_right

    show MK talking at center_left
    MK "Great. It'll be nice to have someone there in case the food is terrible."

    show MK at center_left
    show JK at center_right

    NA "*The two continue eating breakfast, making plans for the weekend.*"


    scene mixer2
    with fade

    show E at center
    with dissolve

    show E sad_talk at center
    voice "E/E61.mp3"
    E "hmm there aren't many places to sit.."

    show E sad at center

    L "Eriq!"

    voice "E/E62.mp3"
    E "!?"

    L "Eriq over here!"

    show E at center_farleft
    with move

    show L at center_left
    with dissolve

    show P at center_farright
    with dissolve

    show I at right
    with dissolve

    show E talk at center_farleft
    voice "E/E63.mp3"
    E "Oh, hey guys!"

    show E at center_farleft

    show I talking at right
    I "Hey Eriq!"

    show I at right

    show P talking at center_farright
    P "Would you like to eat breakfast with us?"

    show P at center_farright

    show E talk at center_farleft
    voice "E/E64.mp3"
    E "Yeah that would be great!"

    show E at center_farleft
    NA "*Sits down*"

    show L talking at center_left
    L "So.."

    show L at center_left
    L "What did everyone do yesterday?"

    show P talking at center_farright
    P "I went to Mr Jackonsky's house and had dinner with them."

    show P at center_farright

    show E talk at center_farleft
    voice "E/E65.mp3"
    E "Oh great, what did you have?"

    show E at center_farleft

    show P talking at center_farright
    P "We had a feast of arbys and pot pies."

    show P at center_farright

    show I talking at right
    I "the fuck"

    show I at right

    show P talking at center_farright
    P "Just kidding! We had chipotle burritos."

    show P at center_farright

    show P talking at center_farright
    P "After eating we played some games and suh sum dih."

    show P at center_farright

    show E talk at center_farleft
    voice "E/E66.mp3"
    E "Sounds like a fun time!"

    show E at center_farleft

    show P talking at center_farright
    P "What about you Eriq?"

    show P at center_farright

    show E talk at center_farleft
    voice "E/E67.mp3"
    E "Well last night all I did was draw in my notebook."

    show E at center_farleft

    show I talking at right
    I "Draw? What were you drawing?"

    show I at right

    show E talk at center_farleft
    voice "E/E68.mp3"
    E "Just some random character designs... and a few doodles."

    show E at center_farleft

    show L talking at center_left
    L "And by random, you mean shirtless men?"

    show L at center_left

    show E at center_farleft
    voice "E/E69.mp3"
    E "uhhhhhhh"

    show P talking at center_farright
    P "quick everyone act surprised."

    show P at center_farright

    show I talking at right
    I "Eriq, are you sure your straight?"

    show I at right

    show I talking at right
    I "I mean what straight guy is so obsessed with shirtless men."

    show I at right

    show E talk at center_farleft
    voice "E/E70.mp3"
    E "I was just drawing it for a friend I promise!."

    show E at center_farleft
    show L at center_left
    show P at center_farright
    show I at right
    NA "*they all glance at each other*"

    show E talk at center_farleft
    voice "E/E71.mp3"
    E "What about you, Liam? You haven't said anything."

    show E at center_farleft

    show L talking at center_left
    L "I mostly stayed home."

    show L at center_left

    show P talking at center_farright
    P "That's it?"

    show P at center_farright

    show L talking at center_left
    L "Pretty much. Played a few games, watched some videos, accidentally took a three hour nap."

    show L at center_left

    show I talking at right
    I "Accidentally?"

    show I at right

    show L talking at center_left
    L "I blinked and it was evening."

    show L at center_left

    show E talk at center_farleft
    voice "E/E72.mp3"
    E "Honestly, yesterday was pretty relaxing."

    show E at center_farleft

    show P talking at center_farright
    P "Too relaxing. We have classes today."

    show P at center_farright

    show I talking at right
    I "Don't remind me."

    show I at right

    show L talking at center_left
    L "Anyone even do the homework?"

    show L at center_left

    show E at center_farleft
    show L at center_left
    show P at center_farright
    show I at right
    NA "*Complete silence.*"

    show P talking at center_farright
    P "...The test for mako is today! And no one did it?"

    show P at center_farright

    show E at center_farleft
    voice "E/E73.mp3"
    E "There was homework?"

    show I talking at right
    I "We're fried."

    show I at right

    play sound "bell.mp3"
    NA "*Bell Rings*"

    show E talk at center_farleft
    voice "E/E74.mp3"
    E "Shit, I have to get to class!"

    jump day1_l1


label friendgroup_D1:

    show E at center
    with dissolve

    E "(i guess i could walk around and find somewhere to sit..)"

    
    L "Eriq!"

    
    E "!?"

    show E sad
    
    L "Eriq over here!"

    show E at center_farleft
    with move

    show L at center_left
    with dissolve

    show P at center_farright
    with dissolve

    show I at right
    with dissolve

    show E talk at center_farleft
    E "Oh, hey guys!"

    show E at center_farleft

    show I talking at right
    I "Hey Eriq!"

    show I at right

    show P talking at center_farright
    P "Would you like to sit with us?"

    show P at center_farright

    show E talk at center_farleft
    E "Yeah that would be great!"

    show E at center_farleft

    NA "*Sits down*"

    show L talking at center_left
    L "So.."

    show L at center_left
    L "What did everyone do yesterday?"

    show P talking at center_farright
    P "I went to Mr Jackonsky's house and had dinner with them."

    show P at center_farright

    show E talk at center_farleft
    E "Oh great, what did you have?"

    show E at center_farleft

    show P talking at center_farright
    P "We had a feast of arbys and pot pies."

    show P at center_farright

    show I talking at right
    I "the fuck"

    show I at right

    show P talking at center_farright
    P "Just kidding! We had chipotle burritos."

    show P at center_farright

    show P talking at center_farright
    P "After eating we played some games and suh sum dih."

    show P at center_farright

    show E talk at center_farleft
    E "Sounds like a fun time!"

    show E at center_farleft

    show P talking at center_farright
    P "What about you Eriq?"

    show P at center_farright

    show E talk at center_farleft
    E "Well last night all I did was draw in my notebook."

    show E at center_farleft

    show I talking at right
    I "Draw? What were you drawing?"

    show I at right

    show E talk at center_farleft
    E "Just some random character designs... and a few doodles."

    show E at center_farleft

    show L talking at center_left
    L "And by random, you mean shirtless men?"

    show L at center_left

    show E at center_farleft
    E "uhhhhhhh"

    show P talking at center_farright
    P "quick everyone act surprised."

    show P at center_farright

    show I talking at right
    I "Eriq, are you sure your straight?"

    show I at right

    show I talking at right
    I "I mean what straight guy is so obsessed with shirtless men."

    show I at right

    show E talk at center_farleft
    E "I was just drawing it for a friend I promise!."

    show E at center_farleft
    show L at center_left
    show P at center_farright
    show I at right

    NA "*they all glance at each other*"

    show E talk at center_farleft
    E "What about you, Liam? You haven't said anything."

    show E at center_farleft

    show L talking at center_left
    L "I mostly stayed home."

    show L at center_left

    show P talking at center_farright
    P "That's it?"

    show P at center_farright

    show L talking at center_left
    L "Pretty much. Played a few games, watched some videos, accidentally took a three hour nap."

    show L at center_left

    show I talking at right
    I "Accidentally?"

    show I at right

    show L talking at center_left
    L "I blinked and it was evening."

    show L at center_left

    show E talk at center_farleft
    E "Honestly, yesterday was pretty relaxing."

    show E at center_farleft

    show P talking at center_farright
    P "Too relaxing. We have classes today."

    show P at center_farright

    show I talking at right
    I "Don't remind me."

    show I at right

    show L talking at center_left
    L "Anyone even do the homework?"

    show L at center_left

    show E at center_farleft
    show L at center_left
    show P at center_farright
    show I at right

    NA "*Complete silence.*"

    show P talking at center_farright
    P "...The test for mako is today! And no one did it?"

    show P at center_farright

    show E at center_farleft
    E "There was homework?"

    show I talking at right
    I "We're fried."

    show I at right

    NA "*they all laugh flowkirkenulenly*"

    show E at center_farleft
    E "Hey.. is that Mr Mako and jackonsky over there?"

    show E at center_farleft

    show I talking at right
    I "Seems like it."

    show I at right

    hide E
    hide P
    hide L
    hide I

    scene mixer

    show MK at center_left
    with dissolve

    show JK at center_right 
    with dissolve

    NA "*Mako and Jackonsky are grading papers together*"

    show MK talking at center_left
    MK "So... Jackonsky, did anything interesting happen yesterday?"

    show MK at center_left

    show JK talking at center_right
    JK "Hmm... not really. It was mostly the same old stuff. What about you?"

    show JK at center_right

    show MK talking at center_left
    MK "Other than failing a few students? Not much."

    show MK at center_left

    show JK talking at center_right
    JK "How come your always failing your students?"

    show JK at center_right

    show MK talking at center_left
    MK "It's called being dedicated."

    show MK at center_left

    show JK talking at center_right
    JK "Pretty sure that's not what dedication means."

    show JK at center_right

    show MK talking at center_left
    MK "Agree to disagree."

    show MK at center_left

    show JK at center_right
    JK "..."

    show JK at center_right

    show MK at center_left
    MK "..."

    NA "*complete silence*"

    show JK talking at center_right
    JK "You know, we're really good at conversations."

    show JK at center_right

    show MK talking at center_left
    MK "*Laughs* Anyway, do you have any plans for this weekend?"

    show MK at center_left

    show MK talking at center_left
    MK "Actually, I was thinking about going to Gag City for lunch."

    show MK at center_left

    show JK talking at center_right
    JK "Really? I've heard good things about that place."

    show JK at center_right

    show MK talking at center_left
    MK "That's what everyone keeps telling me. I figured it was finally time to see if the food is worth all the hype."

    show MK at center_left

    show JK talking at center_right
    JK "And?"

    show JK at center_right

    show MK talking at center_left
    MK "I was wondering if you'd like to come with me."

    show MK at center_left

    show JK talking at center_right
    JK "I'd love that!"

    show JK at center_right

    show MK talking at center_left
    MK "Great. It'll be nice to have someone there in case the food is terrible."

    show MK at center_left
    show JK at center_right

    NA "The two continue grading papers and making plans for the weekend."

    play sound "bell.mp3"
    NA "*Bell Rings*"

    show MK talking at center_left
    MK "Shit, I have to get to class!"

    show MK at center_left

    jump day1_l1









label day1_l1:


    scene moralesclassroom
    with fade

    show E at center
    with dissolve

    E "Looks like I'm the first one here."

    E "Guess I'll get my computer out before everyone else gets here."

    NA "*Eriq sets his backpack on the desk and starts unpacking.*"

    show E at center_right
    with move

    show A at center_left
    with dissolve

    show A talking
    A "Morning, Eriq!"
    show A

    show E talk
    E "Hey, Angel."
    show E

    show A talking
    A "You made it just in time."
    show A

    show E talk
    E "Barely."
    show E

    show A talking
    A "You look exhausted."
    show A

    show A talking
    A "You really need to find a better time for drawing"
    show A

    show E talk
    E "I was only planning on drawing for a little while."
    show E

    show A talking
    A "How long did 'a little while' end up being?"
    show A

    show E talk
    E "A few hours."
    show E

    show A talking
    A "Spoon found in kitchen."
    show A

    show E talk
    E "I didn't even notice how late it got."
    show E

    show A talking
    A "Which means..."
    show A

    show E
    E "..."
    show E talk
    E "...I didn't do Mako's homework."
    show E

    show A talking
    A "I figured."
    show A

    show E talk
    E "I kept telling myself I'd do it after I finished one more sketch."
    show E

    show A talking
    A "And then one more became ten more."
    show A

    show E talk
    E "Pretty much."
    show E

    show A talking
    A "*Giggles* You're hopeless."
    show A

    show E talk
    E "I prefer 'committed.'"
    show E

    show A talking
    A "That's one way to put it."
    show A

    show E talk
    E "So... how bad is today's assignment?"
    show E

    show A talking
    A "Not too bad."
    show A

    show E talk
    E "Please tell me you did it."
    show E

    show A talking
    A "Luckily for you..."
    show A

    show A talking
    A "I did."
    show A

    show E talk
    E "Seriously?"
    show E

    show A talking
    A "Yep."
    show A

    show E talk
    E "You're actually saving my life."
    show E

    show A talking
    A "Don't be dramatic."
    show A

    show E talk
    E "Can I copy it before class starts?"
    show E

    show A talking
    A "Fine... but make it look different."
    show A

    show E talk
    E "Deal. (doh)"
    show E

    show A talking
    A "And this is the last time."
    show A

    show E talk
    E "You said that last time."
    show E

    show A talking
    A "I know."
    show A

    show E talk
    E "Thanks, Angel."
    show E

    show A talking
    A "You owe me."
    show A

    show E talk
    E "How about lunch this weekend?"
    show E

    show A talking
    A "Sounds good."
    show A

    NA "*Angel slides his homework over while Eriq quickly starts copying it.*"
    NA "*More students begin filing into the classroom as the room slowly fills with conversation.*"

    scene moralesclassroom
    with fade

    show E at center
    with dissolve

    E "(Hmm.. where should I go for research?)"

    menu:

        "Where should I go...?"

        "Mixer 1":

            jump mixer1_D1

        "Makers Lab":

            jump makerslab_D1

label makerslab_D1:
    

    E "Hmm... I guess I could work on a project in the maker's lab."

    scene makerslab
    with fade

    show E at center
    with dissolve

    E "Great, it's not too busy in here."
    E "Now let's see... where's a good place to work on my project?"
    E "Oh! I see Liam and Angel over there."
    E "I should go sit with them."

    show E sad at center_farright
    with move

    show L sad at center_left
    with dissolve

    show A sad at center_farleft
    with dissolve

    NA "*As Eriq gets closer, he notices neither of them are smiling.*"

    show L sad_talking at center_left
    L "...I still can't believe he's actually gone."

    show L sad at center_left
    show A sad_talking at center_farleft
    A "I know..."

    A "It doesn't even feel real."

    show A sad at center_farleft
    show L sad_talking at center_left
    L "Every time I walk past his desk, I keep expecting him to be sitting there."

    show L sad at center_left
    show A sad_talking at center_farleft
    A "Me too."

    show A sad at center_farleft
    show L sad at center_left
    show E sad at center_farright

    NA "*Eriq sits down before speaking.*"

    show E sad_talk at center_farright
    E "Uh... hey guys."

    show E sad at center_farright
    show L sad_talking at center_left
    L "Oh, hey Eriq."

    show L sad at center_left
    show A sad_talking at center_farleft
    A "Hi."

    show A sad at center_farleft
    show E sad_talk at center_farright
    E "...Did I interrupt something?"

    show E sad at center_farright
    show L sad_talking at center_left
    L "Not really."

    show L sad at center_left
    show A sad_talking at center_farleft
    A "We were just talking about Joseph."

    show A sad at center_farleft
    show E sad_talk at center_farright
    E "Joseph?"

    show E sad at center_farright
    show L sad_talking at center_left
    L "...You never met him, did you?"

    show L sad at center_left
    show E sad at center_farright
    E "*Shakes head.*"

    show E sad at center_farright
    show A sad_talking at center_farleft
    A "Earlier the teacher announced that Joseph passed away yesterday."

    A "Rumor says he died by suicide..."

    show A sad at center_farleft
    show L sad_talking at center_left
    L "It's a shame you never got to really meet him. You would've liked him."

    L "I think you two would've gotten along."

    show L sad at center_left
    show A sad_talking at center_farleft
    A "Definitely."

    show A sad at center_farleft
    show E sad_talk at center_farright
    E "I'm really sorry..."

    E "Does anyone know why he died?"

    show E sad at center_farright
    show L sad at center_left
    L "*Shakes head.*"

    show L sad_talking at center_left
    L "No one really knows."

    show L sad at center_left
    show A sad_talking at center_farleft
    A "People keep making guesses, but they're just rumors."

    show A sad at center_farleft
    show L sad_talking at center_left
    L "The only thing people keep mentioning is that he apparently had a diary with him before he died."

    show L sad at center_left
    show A sad_talking at center_farleft
    A "Nobody knows what was written in it."

    show A sad at center_farleft
    show E sad at center_farright
    show L sad at center_left

    NA "*The three stand in silence for a moment.*"

    show E sad_talk at center_farright
    E "...I can't imagine what his family must be going through."

    show E sad at center_farright
    show A sad_talking at center_farleft
    A "Me neither."

    show A sad at center_farleft
    show L sad_talking at center_left
    L "It's just... really sad."

    show L sad at center_left
    show A sad at center_farleft
    show E sad at center_farright

    NA "*The three spend the rest of the period in silence with minimal conversation*"

    jump day1_l2


label mixer1_D1:

    E "Hmm... I guess I could go see who's in mixer one."

    scene mixer
    with fade

    show E at center
    with dissolve

    E "Great, it's not too busy in here."
    E "Now let's see... where's a good place to work on my project?"
    E "Oh! I see Isabelle and Pitrah over there."
    E "I should go sit with them."

    show E at center_farright
    with move

    show I at center_left
    with dissolve

    show P at center_farleft
    with dissolve

    show I sad at center_left
    show P sad at center_farleft
    show E sad at center_farright
    with dissolve

    NA "*As Eriq gets closer, he notices neither of them are smiling.*"

    show I sad_talking at center_left
    I "...I still can't believe he's actually gone."

    show I sad at center_left
    show P sad_talking at center_farleft
    P "I know..."

    P "It doesn't even feel real."

    show P sad at center_farleft
    show I sad_talking at center_left
    I "Every time I walk past his desk, I keep expecting him to be sitting there."

    show I sad at center_left
    show P sad_talking at center_farleft
    P "Me too."

    show P sad at center_farleft
    show I sad at center_left
    show E sad at center_farright

    NA "*Eriq sits down before speaking.*"

    show E sad_talk at center_farright
    E "Uh... hey guys."

    show E sad at center_farright
    show I sad_talking at center_left
    I "Oh, hey Eriq."

    show I sad at center_left
    show P sad_talking at center_farleft
    P "Hi."

    show P sad at center_farleft
    show E sad_talk at center_farright
    E "...Did I interrupt something?"

    show E sad at center_farright
    show I sad_talking at center_left
    I "Not really."

    show I sad at center_left
    show P sad_talking at center_farleft
    P "We were just talking about Joseph."

    show P sad at center_farleft
    show E sad_talk at center_farright
    E "Joseph?"

    show E sad at center_farright
    show I sad_talking at center_left
    I "...You never met him, did you?"

    show I sad at center_left
    show E sad at center_farright
    E "*Shakes head.*"

    show E sad at center_farright
    show P sad_talking at center_farleft
    P "Earlier the teacher announced that Joseph passed away yesterday."

    P "Rumor says he died by suicide..."

    show P sad at center_farleft
    show I sad_talking at center_left
    I "It's a shame you never got to really meet him. You would've liked him."

    I "I think you two would've gotten along."

    show I sad at center_left
    show P sad_talking at center_farleft
    P "Definitely."

    show P sad at center_farleft
    show E sad_talk at center_farright
    E "I'm really sorry..."

    E "Does anyone know why he died?"

    show E sad at center_farright
    show I sad at center_left
    I "*Shakes head.*"

    I "No one really knows."

    show I sad at center_left
    show P sad_talking at center_farleft
    P "People keep making guesses, but they're just rumors."

    show P sad at center_farleft
    show I sad_talking at center_left
    I "The only thing people keep mentioning is that he apparently had a diary with him before he died."

    show I sad at center_left
    show P sad_talking at center_farleft
    P "Nobody knows what was written in it."

    show E sad at center_farright
    show I sad at center_left
    show P sad at center_farleft

    NA "*The three stand in silence for a moment.*"

    show E sad_talk at center_farright
    E "...I can't imagine what his family must be going through."

    show E sad at center_farright
    show P sad_talking at center_farleft
    P "Me neither."

    show P sad at center_farleft
    show I sad_talking at center_left
    I "It's just... really sad."

    show E sad at center_farright
    show I sad at center_left
    show P sad at center_farleft

    NA "*The three spend the rest of the period in silence with minimal conversation.*"

    jump day1_l2


label day1_l2:

    play sound "bell.mp3"
    NA "*Bell Rings*"

    E "Guess it's time for lunch."

    scene mixer2
    with fade

    show E at center
    with dissolve

    E "(After a conversation like that, I'm surprised I still have an appetite.)"
    E "(Still... standing around thinking about it isn't going to change anything.)"
    E "(Might as well grab something to eat.)"

    scene lunchline
    with fade

    E "(Im always still full from breakfast whenever I have the *A* lunch period.)"
    E "(Hopefully they have something light.)"
    E "Hello, do you have anything light.. like a salad?"

    voice "LL/LL4.mp3"
    LL "No little gay boy, we dont have the *salad*... so sorry"
    LL "But we do have a taco stick.. take it or leave it."

    E "I- guess I'll take the stick..."

    voice "LL/LL5.mp3" # needs to be voiced still
    LL "Good choice."

    NA "*The lunch lady places a taco stick onto Eriq's tray before sliding it down the counter.*"

    E "(Well.. its nothing compared to my cooking but I guess if it keeps me full.)"

    NA "*Eriq grabs a drink before making his way into the cafeteria.*"

    scene mixer2
    with fade

    show E at center
    with dissolve

    NA "*The cafeteria buzzes with conversations as students enjoy their lunches.*"

    E "(Looks like there are still a few empty tables.)"

    NA "*Eriq finds an empty table near the corner of the room and takes a seat.*"

    E "(Finally... a chance to relax for a bit.)"

    NA "*Eriq quietly unwraps his lunch as the noise of the cafeteria fades into the background.*"

    hide E
    with dissolve

    scene black
    with fade

    NA "The rest of the school day passes by without anything particularly interesting happening."
    NA "Even so, Joseph stays in the back of Eriq's mind for the remainder of the day."
    NA "Eriq spends the afternoon counting down the minutes until the final bell."
    NA "Eventually, the bell rings, and the halls quickly fill with students heading home."

    scene outside
    with fade

    show E at center_right
    with dissolve

    show A at center_left
    with dissolve

    show A at center_right
    show E at center_left
    with dissolve

    show A talking at center_right
    A "So, are we still on for lunch tomorrow?"

    show E talk at center_left
    E "You know I don't make fake promises."

    show A talking at center_right
    A "*Laughs* Just making sure."

    A "I know how easy it is for you to get distracted."

    show E talk at center_left
    E "Hey, I only forget things occasionally."

    show A talking at center_right
    A "You forgot your backpack in the Makers Lab last week."

    show E at center_left
    E "..."

    show A talking at center_right
    A "And your water bottle yesterday."

    show E talk at center_left
    E "Those don't count."

    show A talking at center_right
    A "How do they not count?"

    show E talk at center_left
    E "Because I remembered them eventually."

    show A talking at center_right
    A "Yeah, after I told you."

    show E at center_left
    E "*Chuckles*"

    show A talking at center_right
    A "Anyway, I'll meet you at the spot near 11."

    show E talk at center_left
    E "Sounds good."

    show A talking at center_right
    A "Don't be late."

    show E talk at center_left
    E "I'll try."

    show A talking at center_right
    A "'Try' doesn't exactly fill me with confidence."

    show E talk at center_left
    E "Fine... I'll be there."

    show A talking at center_right
    A "Good."

    show E talk at center_left
    E "See you tomorrow, Angel."

    show A talking at center_right
    A "See you tomorrow, Eriq."

    show E at center_left
    show A at center_right

    hide A
    hide E
    with dissolve

    scene sky-morning
    with fade

    pause 1.0

    scene sky-night
    with Dissolve(3.0)

    pause 1.0
    
    scene sky-morning
    with Dissolve(3.0)

    pause

    scene thankyouscreen
    with fade

    NA "Another demo another slay period!!!"
    NA "While I know some people may be very sad that the OG sprites are gone and replaced with... much much better sprites."
    NA "Dont worry because its still the same crappy story!"
    NA "I mean cmon is still me writing this like bsfr"
    NA "but like awww so cute look at the little chibi's"
    I "I think isabelle"
    A "and angel might be a favoite like aww"
    NA "Anyway wahoo we made it"
    NA "If this was your first time playing congrats!"
    NA "And if this isnt your first time.."
    NA "Ha imagine loser"
    NA "anyway"
    NA "HAPPY YAOI DAY"
    NA "HAVE A SPOONTASTIC DAY!!!!"