﻿define MK = Character('Mr Mako', color="#86A1B3") #aiden
image MK = "images/MK/MK.png"

define JO = Character('Joseph', color="#3E3DA3FF") #joseph?
image JO = "images/JO/JO.png"

define CK = Character('Charlie Kirk', color="#8A1616") #joseph?
image CK = "images/CK/CK.png"

define JK = Character('Mr Jackonsky', color="#C3EC63")
image JK = "images/JK/JK.png"

define TV = Character('Television', color="#4F2E2D")

define NS = Character('Nurse', color="#264FAD")

define L = Character('Liam', color="#77C8E0")
image L = "images/L/L.png"

define P = Character('Pitrah', color="#A363EC")
image P = "images/P/P.png"

define I = Character('Isabelle', color="#FF6F6F")
image I = "images/I/I.png"

define E = Character('Eriq', color="#dbd6aa")
image E = "images/E/E.png"

define NA = Character('', color="#575757",)

define A = Character('Angel', color="#F0AEE7")
image A = "images/A/A.png"

define LL = Character('Lunch Lady', color="#82cabe") #aiden

default angelpoints = 0
default josephpoints = 0



transform center_left:
    xalign 0.4
    yalign 1.0

transform center_farleft:
    xalign 0.2
    yalign 1.0

transform center_right:
    xalign 0.6
    yalign 1.0

transform center_farright:
    xalign 0.8
    yalign 1.0


#usefull stuff
#play music "music.mp3"
#show char = show E happy
#hide char = hide E

#show e happy at left
#with move


image mixer = im.Scale("mixer.jpg", 1920, 1080)

label start:

    scene black
    scene warning
    with fade
    pause
    scene black

    E "Being closeted means carrying a truth you can’t always say out loud."
    E "It’s editing yourself, watching your words, and hiding parts of who you are just to feel safe."
    E "People may think they know you, but they only see what you’re allowed to show."
    E "Staying closeted isn’t weakness."
    E "It’s survival."
    E "There’s no deadline to come out and no rule that says you owe anyone your truth before you’re ready."
    E "You are valid even in silence, and when the time comes, your story will still be yours to tell."
    E "Am I ready?"


    scene bathroomscene
    with fade

    

    play sound "gunshot.mp3"

    NA "*Gunshot*"
    JO "I couldn't do it anymore"
    JO "Knowing what I do.."
    JO "How could I live knowing what I did..?"
    JO "I had to do it"
    JO "Despite what they said"
    JO "Who could stop them?"
    JO "Why even try..?"
    JO "I dont regret what I did"
    JO "..."
    JO "Where do we go when we pass..?"
    JO "Billie eilish might know"
    JO "But I sure dont"
    JO "Regardless.."
    JO "Life will go on"
    JO "The sun will rise and fall"
    JO "Water will flow"
    JO "Kids will use research time irresponsibly"
    JO "And Eriq will still think he's straight."
    JO "The show must go on..."

    jump realstart
    

label realstart:
    

    play music [
    "audio/wearecharliekirkHYPERPOP.mp3",
    "audio/wearecharliekirkFONK.mp3",
    "audio/wearecharliekirkOG.mp3",
    "audio/fivenightsatkirkys.mp3",
    "audio/wearecharliekirkJERSEYDRILLREMIX.mp3"
    ] fadein 1.5 fadeout 1.5 loop
    
    scene outside
    with fade

    show E at center
    with dissolve
    E "Another day another slayy perriouddd!!"
    E "(Sophomore has been very stressfull)"
    E "(With all of the classes and drama going on its hard to get any sleep)"
    E "(But one person keeps me going..)"
    E "(My friend Angel!)"
    
    show E at center_left
    with dissolve

    show A at center_right
    with dissolve

    A "Hya there Eriq!"
    A "How did you sleep last night?"

    E "Not well, I stayed up last night till 2am doing homework for Mr. Morales."

    A "Well thats not good, you should really work on getting better sleep!"
    A "Why didn't you do it in research?"

    E "I was drawing as usual.."

    A "Classic Eriq..."
    A "You know.."
    A "For a straight guy, you draw a lot of shirtless men."

    E ".."
    E "gyulp"

    A "Hahah just yanking your chain"
    A "Lets get inside before were late"

    E "Heh.. yeah you're right.."

    hide A
    hide E
    


    scene mixer
    with fade

    show E at center
    with dissolve

    E "The mixer.."
    E "For a small school like Neocity there are alot of people here in the morning."
    E "Everyone finds their group"
    E "Gets breakfast"
    E "And prepares for class"
    E "Where am I going to go...?"

    menu:

        "Where am I going to go...?"

        "Breakfast line":

            jump breakfast_D1

        "Walk around":

            jump friendgroup_D1
    

label breakfast_D1:
    E "*rumble.. rumble*"
    E "…Wow, my stomach is not being subtle today."
    E "I really forgot to eat breakfast this morning."
    E "That’s what I get for hitting snooze one too many times."
    E "Guess I’ll get some breakfast before I pass out in class."

    scene mixer2
    with fade

    show E at center
    with dissolve

    E "(Wow, the second mixer is pretty packed.)"
    E "(So much for it being early.)"
    E "(Guess a lot of people had the same idea this morning.)"
    E "(Everyone’s chatting and laughing like they’re wide awake.)"
    E "(I don’t understand how anyone has this much energy before seven.)"
    E "(It’s too fucking loud in here for six in the morning.)"
    E "(My head hurts a little, but food should help.)"
    E "(At least today’s breakfast is supposed to be good.)"
    E "(For a school full of twinks there sure are a lot of fatasses)"
    E "(I knew coming early wouldn’t mean avoiding the line.)"
    E "(It never does.)"
    E "(Still better than waiting even longer.)"
    E "(Might as well get in it now.)"

    scene lunchline
    with fade

    E "(God, I hope this line moves quickly.)"
    E "(My stomach feels like it’s eating itself.)"
    E "(I don’t want to rush through eating.)"
    E "(But I also don’t want to be late for my first class.)"
    E "(Why is everything a trade-off this early in the day?)"

    voice "LL/LL1.mp3"
    LL "Don’t forget your fruit, honey."

    E "Oh— yeah. Sorry."
    E "I always forget that part."
    E "*grabs fruit*"
    E "(At least it looks fresh today.)"

    voice "LL/LL2.mp3"
    LL "Scan your ID now."

    E "*scans*"
    E "(I wonder how many times she’s seen my name pop up this semester.)"

    voice "LL/LL3.mp3"
    LL "Next in line, please."

    E "(I can’t tell sometimes if the lunch lady loves me or hates me.)"
    E "(Her tone never changes.)"
    E "(Whatever.)"
    E "(Now I just need to find a seat somewhere.)"
    E "(Preferably one that isn’t right next to the loudest table.)"



    scene mixer2
    with fade

    show MK at center_left
    with dissolve
    show JK at center_right 
    with dissolve

    MK "*Eating breakfast*"
    JK "*Eating breakfast*"
    MK "So... Jackonsky, did anything interesting happen yesterday?"
    JK "Hmm... not really. It was mostly the same old stuff. What about you?"
    MK "Other than failing a few students? Not much."
    JK "How come your always failing your students?"
    MK "It's called being dedicated."
    JK "Pretty sure that's not what dedication means."
    MK "Agree to disagree."
    JK "..."
    MK "..."
    NA "complete silence"
    JK "You know, we're really good at conversations."
    MK "*Laughs* Anyway, do you have any plans for this weekend?"
    MK "Actually, I was thinking about going to Gag City for lunch."
    JK "Really? I've heard good things about that place."
    MK "That's what everyone keeps telling me. I figured it was finally time to see if the food is worth all the hype."
    JK "And?"
    MK "I was wondering if you'd like to come with me."
    JK "I'd love that!"
    MK "Great. It'll be nice to have someone there in case the food is terrible."
    NA "The two continue eating breakfast, making plans for the weekend."


    scene mixer2
    with fade

    show E at center
    with dissolve

    E "hmm there aren't many places to sit.."

    L "Eriq!"

    E "!?"

    L "Eriq over here!"

    show E at center_farleft
    with move

    show L at center_left
    with dissolve

    show P at center_farright
    with dissolve

    show I at right
    with dissolve

    E "Oh, hey guys!"

    I "Hey Eriq!"

    P "Would you like to eat breakfast with us?"

    E "Yeah that would be great!"
    
    NA "*Sits down*"

    L "So.."

    L "What did everyone do yesterday?"

    P "I went to Mr Jackonsky's house and had dinner with them."

    E "Oh great, what did you have?"

    P "We had a feast of arbys and pot pies."

    I "the fuck"

    P "Just kidding! We had chipotle burritos."

    P "After eating we played some games and suh sum dih."

    E "Sounds like a fun time!"

    P "What about you Eriq?"

    E "Well last night all I did was draw in my notebook."

    I "Draw? What were you drawing?"

    E "Just some random character designs... and a few doodles."

    L "And by random, you mean shirtless men?"

    E "uhhhhhhh"

    P "quick everyone act surprised."

    I "Eriq, are you sure your straight?"

    I "I mean what straight guy is so obsessed with shirtless men."

    E "I was just drawing it for a friend I promise!."

    NA "they all glance at each other"

    E "What about you, Liam? You haven't said anything."

    L "I mostly stayed home."

    P "That's it?"

    L "Pretty much. Played a few games, watched some videos, accidentally took a three hour nap."

    I "Accidentally?"

    L "I blinked and it was evening."

    E "Honestly, yesterday was pretty relaxing."

    P "Too relaxing. We have classes today."

    I "Don't remind me."

    L "Anyone even do the homework?"

    NA "*Complete silence.*"

    P "...The test for mako is today! And no one did it?"

    E "There was homework?"

    I "We're fried."

    play sound "bell.mp3"
    NA "*Bell Rings*"

    E "Shit, I have to get to class!"

    jump day1_l1


label friendgroup_D1:

    E "(i guess i could walk around and find somewhere to sit..)"

    L "Eriq!"

    E "!?"

    L "Eriq over here!"

    show E at center_farleft
    with move

    show L at center_left
    with dissolve

    show P at center_farright
    with dissolve

    show I at right
    with dissolve

    E "Oh, hey guys!"

    I "Hey Eriq!"

    P "Would you like to sit with us?"

    E "Yeah that would be great!"
    
    NA "*Sits down*"

    L "So.."

    L "What did everyone do yesterday?"

    P "I went to Mr Jackonsky's house and had dinner with them."

    E "Oh great, what did you have?"

    P "We had a feast of arbys and pot pies."

    I "the fuck"

    P "Just kidding! We had chipotle burritos."

    P "After eating we played some games and suh sum dih."

    E "Sounds like a fun time!"

    P "What about you Eriq?"

    E "Well last night all I did was draw in my notebook."

    I "Draw? What were you drawing?"

    E "Just some random character designs... and a few doodles."

    L "And by random, you mean shirtless men?"

    E "uhhhhhhh"

    P "quick everyone act surprised."

    I "Eriq, are you sure your straight?"

    I "I mean what straight guy is so obsessed with shirtless men."

    E "I was just drawing it for a friend I promise!."

    NA "they all glance at each other"

    E "What about you, Liam? You haven't said anything."

    L "I mostly stayed home."

    P "That's it?"

    L "Pretty much. Played a few games, watched some videos, accidentally took a three hour nap."

    I "Accidentally?"

    L "I blinked and it was evening."

    E "Honestly, yesterday was pretty relaxing."

    P "Too relaxing. We have classes today."

    I "Don't remind me."

    L "Anyone even do the homework?"

    NA "*Complete silence.*"

    P "...The test for mako is today! And no one did it?"

    E "There was homework?"

    I "We're fried."

    NA "*they all laugh flowkirkenulenly*"

    E "Hey.. is that Mr Mako and jackonsky over there?"

    I "Seems like it."

    hide E
    hide P
    hide L
    hide I

    scene mixer
    
    show MK at center_left
    with dissolve
    show JK at center_right 
    with dissolve

    NA "*Mako and Jackonsky are grading papers together*"
    MK "So... Jackonsky, did anything interesting happen yesterday?"
    JK "Hmm... not really. It was mostly the same old stuff. What about you?"
    MK "Other than failing a few students? Not much."
    JK "How come your always failing your students?"
    MK "It's called being dedicated."
    JK "Pretty sure that's not what dedication means."
    MK "Agree to disagree."
    JK "..."
    MK "..."
    NA "complete silence"
    JK "You know, we're really good at conversations."
    MK "*Laughs* Anyway, do you have any plans for this weekend?"
    MK "Actually, I was thinking about going to Gag City for lunch."
    JK "Really? I've heard good things about that place."
    MK "That's what everyone keeps telling me. I figured it was finally time to see if the food is worth all the hype."
    JK "And?"
    MK "I was wondering if you'd like to come with me."
    JK "I'd love that!"
    MK "Great. It'll be nice to have someone there in case the food is terrible."
    NA "The two continue grading papers and making plans for the weekend."

    play sound "bell.mp3"
    NA "*Bell Rings*"
    MK "Shit, I have to get to class!"


    jump day1_l1









label day1_l1:


    scene moralesclassroom
    with fade

    show E at center
    with dissolve

    E "Looks like I'm the first one here."

    E "Guess I'll get my computer out before everyone else gets here."

    NA "*Eriq sets his backpack on the desk and starts unpacking.*"

    show E at center_right
    with move

    show A at center_left
    with dissolve

    A "Morning, Eriq!"

    E "Hey, Angel."

    A "You made it just in time."

    E "Barely."

    A "You look exhausted."
    A "You really need to find a better time for drawing"

    E "I was only planning on drawing for a little while."

    A "How long did 'a little while' end up being?"

    E "A few hours."

    A "spoon found in kitchen"

    E "I didn't even notice how late it got."

    A "Which means..."

    E "...I didn't do Mako's homework."

    A "I figured."

    E "I kept telling myself I'd do it after I finished one more sketch."

    A "And then one more became ten more."

    E "Pretty much."

    A "*Giggles* You're hopeless."

    E "I prefer 'committed'"

    A "That's one way to put it."

    E "So... how bad is today's assignment?"

    A "Not too bad."

    E "Please tell me you did it."

    A "Luckily for you..."
    A "I did."

    E "Seriously?"

    A "Yep."

    E "You're actually saving my life."

    A "Don't be dramatic."

    E "Can I copy it before class starts?"

    A "Fine... but make it look different."

    E "Deal  (doh)."

    A "And this is the last time."

    E "You said that last time."

    A "I know."

    E "Thanks, Angel."

    A "You owe me."

    E "How about lunch this weekend"

    A "Sounds good."

    NA "*Angel slides his homework over while Eriq quickly starts copying it.*"
    NA "*More students begin filing into the classroom as the room slowly fills with conversation.*"

    scene moralesclassroom
    with fade

    show E at center
    with dissolve

    E "(Hmm.. where should I go for research?)"

    menu:

        "Where should I go...?"

        "Mixer 1":

            jump mixer1_D1

        "Makers Lab":

            jump makerslab_D1

label makerslab_D1:
    

    E "Hmm... I guess I could work on a project in the maker's lab."

    scene makerslab
    with fade

    show E at center
    with dissolve

    E "Great, it's not too busy in here."
    E "Now let's see... where's a good place to work on my project?"
    E "Oh! I see Liam and Angel over there."
    E "I should go sit with them."

    show E at center_right
    with move

    show L at center_left
    with dissolve

    show A at center_farleft
    with dissolve

    NA "*As Eriq gets closer, he notices neither of them are smiling.*"

    L "...I still can't believe he's actually gone."

    A "I know..."

    A "It doesn't even feel real."

    L "Every time I walk past his desk, I keep expecting him to be sitting there."

    A "Me too."

    NA "*Eriq slows down before speaking.*"

    E "Uh... hey guys."

    L "Oh, hey Eriq."

    A "Hi."

    E "...Did I interrupt something?"

    L "Not really."

    A "We were just talking about Joseph."

    E "Joseph?"

    L "...You never met him, did you?"

    E "*Shakes head.*"

    A "Earlier the teacher announced that Joseph passed away yesterday"
    A "Rumor says he took his own life.."

    L "It a shame you never got to really meet him, you would have liked him."

    L "I think you two would've gotten along."

    A "Definitely."

    E "I'm really sorry..."

    E "Does anyone know why he did it?"

    L "*Shakes head.*"

    L "No one really knows."

    A "People keep making guesses, but they're just rumors."

    L "The only thing people keep mentioning is that he apparently had a diary with him before he died."

    A "Nobody knows what was written in it."

    NA "*The three stand in silence for a moment.*"

    E "...I can't imagine what his family must be going through."

    A "Me neither."

    L "It's just... really sad."

    NA "*The three spend the rest of the period in silence with minimal conversation*"

    jump day1_l2


label mixer1_D1:

    E "Hmm... I guess I could go see who's in mixer one."

    scene mixer
    with fade

    show E at center
    with dissolve

    E "Great, it's not too busy in here."
    E "Now let's see... where's a good place to work on my project?"
    E "Oh! I see Isabelle and Pitrah over there."
    E "I should go sit with them."

    show E at center_right
    with move

    show I at center_left
    with dissolve

    show P at center_farleft
    with dissolve

    NA "*As Eriq gets closer, he notices neither of them are smiling.*"

    I "...I still can't believe he's actually gone."

    P "I know..."

    P "It doesn't even feel real."

    I "Every time I walk past his desk, I keep expecting him to be sitting there."

    P "Me too."

    NA "*Eriq slows down before speaking.*"

    E "Uh... hey guys."

    I "Oh, hey Eriq."

    P "Hi."

    E "...Did I interrupt something?"

    I "Not really."

    P "We were just talking about Joseph."

    E "Joseph?"

    I "...You never met him, did you?"

    E "*Shakes head.*"

    P "Earlier the teacher announced that Joseph passed away yesterday"
    P "Rumor says he took his own life.."

    I "It a shame you never got to really meet him, you would have liked him."
    I "I think you two would've gotten along."

    P "Definitely."

    E "I'm really sorry..."
    E "Does anyone know why he did it?"

    I "*Shakes head.*"

    I "No one really knows."

    P "People keep making guesses, but they're just rumors."

    I "The only thing people keep mentioning is that he apparently had a diary with him before he died."

    P "Nobody knows what was written in it."

    NA "*The three stand in silence for a moment.*"

    E "...I can't imagine what his family must be going through."

    P "Me neither."

    I "It's just... really sad."

    NA "*The three spend the rest of the period in silence with minimal conversation*"

    jump day1_l2


label day1_l2:

    play sound "bell.mp3"
    NA "*Bell Rings*"

    E "Guess it's time for lunch."

    scene mixer2
    with fade

    show E at center
    with dissolve

    E "(After a conversation like that, I'm surprised I still have an appetite.)"
    E "(Still... standing around thinking about it isn't going to change anything.)"
    E "(Might as well grab something to eat.)"

    scene lunchline
    with fade

    E "(Im always still full from breakfast whenever I have the *A* lunch period.)"
    E "(Hopefully they have something light.)"
    E "Hello, do you have anything light.. like a salad?"

    voice "LL/LL4.mp3"
    LL "No little gay boy, we dont have the *salad*... so sorry"
    LL "But we do have a taco stick.. take it or leave it."

    E "I- guess I'll take the stick..."

    voice "LL/LL5.mp3" # needs to be voiced still
    LL "Good choice."

    NA "*The lunch lady places a taco stick onto Eriq's tray before sliding it down the counter.*"

    E "(Well.. its nothing compared to my cooking but I guess if it keeps me full.)"

    NA "*Eriq grabs a drink before making his way into the cafeteria.*"

    scene mixer2
    with fade

    show E at center
    with dissolve

    NA "*The cafeteria buzzes with conversations as students enjoy their lunches.*"

    E "(Looks like there are still a few empty tables.)"

    NA "*Eriq finds an empty table near the corner of the room and takes a seat.*"

    E "(Finally... a chance to relax for a bit.)"

    NA "*Eriq quietly unwraps his lunch as the noise of the cafeteria fades into the background.*"

    hide E
    with dissolve

    scene black
    with fade

    NA "The rest of the school day passes by without anything particularly interesting happening."
    NA "Even so, Joseph stays in the back of Eriq's mind for the remainder of the day."
    NA "Eriq spends the afternoon counting down the minutes until the final bell."
    NA "Eventually, the bell rings, and the halls quickly fill with students heading home."

    scene outside
    with fade

    show E at center_right
    with dissolve

    show A at center_left
    with dissolve

    A "So, are we still on for lunch tomorrow?"

    E "You know I don't make fake promises."

    A "*Laughs* Just making sure."

    A "I know how easy it is for you to get distracted."

    E "Hey, I only forget things occasionally."

    A "You forgot your backpack in the Makers Lab last week."

    E "..."

    A "And your water bottle yesterday."

    E "Those don't count."

    A "How do they not count?"

    E "Because I remembered them eventually."

    A "Yeah after I told you."

    E "*Chuckles*"

    A "Anyway, I'll be at your house at 11 to pick you up."

    E "Sounds good."

    A "Don't be late."

    E "I'll try."

    A "'Try' doesn't exactly fill me with confidence."

    E "Fine... I'll be there."

    A "Good."

    E "See you tomorrow, Angel."

    A "See you tomorrow, Eriq."

    hide A
    hide E
    with dissolve

    scene sky-morning
    with fade

    pause 1.0

    scene sky-night
    with Dissolve(3.0)

    pause 1.0
    
    scene sky-morning
    with Dissolve(3.0)

    pause

    scene thankyouscreen
    with fade

    pause

    NA "Wassup goodie gang..."
    NA "Thanks for playing this awsome demo."
    NA "I hope this demo met your very very very high expectations."
    NA "As writing this message the current word count is well over 5,000 words for the main game... in comparison this demo is less than 2,500.."
    NA "So much more is planned (unfortunately)"
    NA "Anyways have a great national yaoi day."
    NA "Im gonna bake a cake if anyone wants a slice."
    NA "Made with fresh milk from Mr A's farm of course."
    NA "okay okay im rambling now."
    NA "also if this gets out everyone is coming down with me."
    NA "BYE GUYS HAVE A SPOONTASTIC DAY!!! WISH MANY SPOONS IN YOUR FUTURE!!"